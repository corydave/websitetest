FLCC — COORDINATED SCHEMATIC FLOOR MODELS

START HERE
Open FLCC-coordinated-viewer.html in a WebGL-capable browser. Toggle individual
floors, rotate, zoom, or use Explode to separate levels for inspection.
Drag to orbit; Shift-drag to pan; scroll to zoom. Arrow keys orbit, +/- zoom,
Home resets. The viewer is self-contained and works offline.

IMPORTING AND STACKING
The individual FLCC-aligned-floor-1 through floor-4 models share an origin,
orientation, and assumed meter units. Import all at their native coordinates.
Do not independently center, normalize, resize, or drop each file to the ground.
Y is up. Floor surfaces are at Y = 0, 3.5, 7.0, and 10.5 meters respectively.
STL does not encode units; choose the same import units for every file.
If software automatically centers individual imports, use the combined model.
FLCC-aligned-all-floors contains all four levels already placed together.
OBJ colors require the same-named MTL file beside the OBJ. GLB includes colors.
The STL contains geometry only. No roof or separate ceiling meshes are added.

WHAT CHANGED
The earlier models used separate diagram scales. These revisions register the
main stair core and elevator centers to a common coordinate frame, rescale and
reposition wings, relocate the fourth-floor Allied Health inset, and assign
consistent floor elevations. Library access cores on floors 1-3 share selected
control points. The athletic block footprint has been expanded northward using
an estimate informed by the supplied exterior views. Additional surface
subdivision preserves local changes of scale. No survey measurements were used.

ACCURACY AND REMAINING LIMITATIONS
This is a coordinated schematic study, not a measured reconstruction.
The selected main stair corners coincide numerically across all four levels.
This proves alignment at those chosen anchors, not that every secondary stair,
room, exterior wall, or wing boundary is physically exact. The wayfinding plans
use inconsistent proportions and inset layouts. Local stretching, tapering,
and imperfect connections remain in areas those diagrams cannot reconcile.
A measured plan or known dimensions would be needed to resolve these areas.

The meter scale, 3.5 m floor spacing, 3.2 m wall heights, window arrangements,
and gym footprint are estimates. The sloped site and split levels are omitted.
Stairs remain simplified symbols/volumes; continuous inter-floor circulation,
slab openings, and a walkable or structurally consistent stair system have not
been reconstructed. The overlapping mesh components are not a boolean-unioned,
print-ready solid. Some small partitions and doorway details are simplified.
These files stack in a common scene; they are not construction/BIM drawings.

CHECKS
The STL triangle counts and byte lengths, OBJ face counts, and GLB headers were
validated. Main stair registration residuals are recorded in registration-checks.json.
The mesh was rendered for inspection. Viewer JavaScript syntax was checked;
an interactive browser runtime was unavailable for full viewer runtime testing.

EDITABLE SOURCE
source/build_coordinated.py and source/align_config.py contain registration
logic and editable control points. The source folder includes the four input
mesh datasets. Requires Python, NumPy, and SciPy. Run from the source folder;
new exports are written to its coordinated subfolder. Floorplan photographs
and original uploads are not required by this registration script.

from pathlib import Path
import numpy as np,json,struct,math
from scipy.spatial import Delaunay
from align_config import CONFIG
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'coordinated';OUT.mkdir(exist_ok=True)
class Warp:
 def __init__(self,anchors):
  a=np.array(anchors,float);self.src=a[:,:2];self.dst=a[:,2:];self.d=Delaunay(self.src);self.centers=self.src[self.d.simplices].mean(axis=1)
 def __call__(self,p):
  p=np.asarray(p);shape=p.shape;p=p.reshape(-1,2);ids=self.d.find_simplex(p);outside=ids<0
  if outside.any():ids[outside]=((p[outside,None,:]-self.centers[None,:,:])**2).sum(2).argmin(1)
  t=self.d.transform[ids];uv=np.einsum('nij,nj->ni',t[:,:2],p-t[:,2]);w=np.c_[uv,1-uv.sum(1)]
  return np.einsum('ni,nij->nj',w,self.dst[self.d.simplices[ids]]).reshape(shape)
warps={i:Warp(c['anchors']) for i,c in CONFIG.items() if c['anchors']}
def interp(v,x,y):
 out=np.interp(v,x,y);out=np.where(v<x[0],y[0]+(v-x[0])*(y[1]-y[0])/(x[1]-x[0]),out);return np.where(v>x[-1],y[-1]+(v-x[-1])*(y[-1]-y[-2])/(x[-1]-x[-2]),out)
def library(i,p):
 x,y=p.T
 if i==1:return np.c_[interp(x,[1403,1405,1436,1702],[1145,1163,1195,1455]),interp(y,[179,307,364,459,568],[448,554,600,694,794])]
 return np.c_[interp(x,[948,1001,1017,1176],[1145,1163,1195,1455]),interp(y,[609,694,726,797],[448,554,600,694])]
# Shared aerial-guided north athletic footprint: estimated 41.7 m x 34.8 m.
# Smoothly transition into the adjoining main academic wing.
def north_shape(p):
 p=p.astype(float).copy();f=np.clip((p[:,0]-796)/141,0,1);p[:,1]-=244*np.clip((138-p[:,1])/104,0,1)*f;return p
# Gym corners and two shared access stair rectangles.
ga=[(879,262,937,34),(1173,262,1354,34),(879,559,937,172),(1173,559,1354,172)]
for sx,sy,tx,ty in [(882,476,843,320),(903,476,860,320),(882,505,843,348),(903,505,860,348),(1130,477,1085,320),(1146,477,1105,320),(1130,505,1085,348),(1146,505,1105,348)]:
 q=warps[3](np.array([[tx,ty]]))[0];ga.append((sx,sy,*q))
gym=Warp(ga)
def core3(p):
 x,y=p.T
 xn=interp(x,[556,665,686,688,794,841],[627,742,762,796,926,937])
 xs=interp(x,[556,611,617,624,636,649,665,688,794],[629,678,702,710,731,750,767,796,939])
 blend=np.clip((y-400)/118,0,1)
 yy=interp(y,[195,244,269,308,400,518,553,650,691,728,738,760,812,848],[49,77,127,183,200,324,369,500,552,600,612,667,710,737])
 return np.c_[xn*(1-blend)+xs*blend,yy]
def mapping(i,p,section='main'):
 p=np.asarray(p,dtype=float).reshape(-1,2);x,y=p.T
 if i in [1,3] and section=='library':q=library(i,p)
 elif i==4 and section=='gym':q=np.c_[interp(x,[879,1173],[937,1354]),interp(y,[262,476,505,559],[34,128,148,172])]
 elif i==4 and section=='allied':
  q=np.c_[interp(x,[557,686],[556,688]),interp(y,[211,226,263,340],[180,195,256,308])];q=core3(q)
 elif section=='seneca':
  if i==2:q=np.c_[x,interp(y,[174,324,369],[200,324,369])]
  elif i==3:q=np.c_[interp(x,[246,556],[212,629]),interp(y,[277,402,518,553],[64,200,324,369])]
  else:q=np.c_[interp(x,[240,556],[212,629]),interp(y,[371,427,547,580],[135,200,324,369])]
 elif i==3 and section=='keuka':q=np.c_[interp(x,[841,1110,1158],[937,1354,1423]),interp(y,[210,338,377,450],[34,138,172,231])]
 elif i==3:q=core3(p)
 elif i==4:q=np.c_[interp(x,[556,610,615,632,648,692,795],[629,694,702,710,750,796,939]),interp(y,[427,547,580,647,719,754,768,790,842,877],[174,324,369,450,552,600,612,667,710,737])]
 elif i==2:q=p.copy()
 else:q=warps[i](p)
 return north_shape(q)
def section(i,cent):
 if i==1 and cent[0]>=1403:return 'library'
 if i==3 and cent[0]>=940 and cent[1]>=590:return 'library'
 if i==3 and cent[0]>=841 and cent[1]<500:return 'keuka'
 if i==3 and cent[0]<556:return 'seneca'
 if i==2 and cent[0]<627 and cent[1]<420:return 'seneca'
 if i==4:
  if cent[0]<556 and cent[1]<600:return 'seneca'
  if cent[0]>=850:return 'gym'
  if cent[1]<350 and 540<cent[0]<710:return 'allied'
 return 'main'
def split(tris,limit):
 # Adaptive subdivision keeps long surfaces faithful to local registration.
 done=[];todo=list(tris)
 while todo:
  t=todo.pop();lengths=[np.linalg.norm(t[(j+1)%3]-t[j]) for j in range(3)];j=int(np.argmax(lengths))
  if lengths[j]<=limit:done.append(t);continue
  k=(j+1)%3;l=(j+2)%3;m=(t[j]+t[k])/2;todo.extend([np.array([t[j],m,t[l]]),np.array([m,t[k],t[l]])])
 return np.array(done)
allgroups={};stats={};audits=[]
for i,c in CONFIG.items():
 data=json.loads((ROOT/c['dir']/'model-data.json').read_text());groups={};nold=0
 for name,obj in data.items():
  t=np.array(obj['triangles'],float);nold+=len(t)
  # Source units -> plan pixels; subdivide along boundaries in the shared warp.
  t=split(t,6 if name=='Floor slab' else 3.5)
  pix=t[:,:,[0,2]]*10+np.array(c['center']);cent=pix.mean(axis=1);out=t.copy()
  sec=np.array([section(i,p) for p in cent])
  for st in set(sec):
   choose=sec==st;q=mapping(i,pix[choose].reshape(-1,2),st).reshape(-1,3,2)
   out[choose,:,0]=(q[:,:,0]-790)*.1;out[choose,:,2]=(q[:,:,1]-440)*.1
  out[:,:,1]+=(i-1)*3.5
  assert np.isfinite(out).all()
  groups[name]={'color':obj['color'],'triangles':out.round(5).tolist()}
  allgroups[f'Floor {i} / {name}']={'color':obj['color'],'triangles':out.round(5).tolist(),'floor':i}
 stats[i]={'source_triangles':nold,'export_triangles':sum(len(o['triangles']) for o in groups.values()),'elevation_m':(i-1)*3.5}
 (OUT/f'floor-{i}-data.json').write_text(json.dumps(groups,separators=(',',':')))
 # Primary stair shaft registration: exact corresponding corners, independently measured after warp.
 src={1:[[787,305],[834,305],[787,336],[834,336]],2:[[710,552],[750,552],[710,600],[750,600]],3:[[624,691],[649,691],[624,728],[649,728]],4:[[632,719],[648,719],[632,754],[648,754]]}[i]
 pts=mapping(i,np.array(src));target=np.array([[710,552],[750,552],[710,600],[750,600]])
 audits.append({'floor':i,'main_stair_max_registration_error_m':float(np.max(np.linalg.norm(pts-target,axis=1))*.1)})
 print(i,stats[i])
(OUT/'model-data.json').write_text(json.dumps(allgroups,separators=(',',':')))
(OUT/'registration-checks.json').write_text(json.dumps({'floors':stats,'stair_checks':audits,'note':'Residuals test chosen schematic control points, not surveyed accuracy.'},indent=2))
def export(groups,stem):
 faces=[t for o in groups.values() for t in o['triangles']];a=np.array(faces,dtype=np.float32);normal=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);normal/=np.maximum(np.linalg.norm(normal,axis=1)[:,None],1e-12)
 record=np.zeros(len(a),dtype=[('n','<f4',(3,)),('v','<f4',(3,3)),('attr','<u2')]);record['n']=normal;record['v']=a
 (OUT/(stem+'.stl')).write_bytes(b'FLCC coordinated floors; assumed meters; Y-up; retain native origins'.ljust(80,b'\0')+struct.pack('<I',len(a))+record.tobytes())
 obj=[f'# Coordinated FLCC floors; assumed meters, Y up\nmtllib {stem}.mtl\n'];mtl=[];idx=1
 for name,o in groups.items():
  nm=name.replace(' / ','_').replace(' ','_');obj.append(f'o {nm}\nusemtl {nm}\n');col=o['color'];mtl.append(f'newmtl {nm}\nKd {col[0]} {col[1]} {col[2]}\nd {col[3]}\n')
  for t in o['triangles']:
   obj.extend('v '+' '.join(f'{v:.5f}' for v in p)+'\n' for p in t);obj.append(f'f {idx} {idx+1} {idx+2}\n');idx+=3
 (OUT/(stem+'.obj')).write_text(''.join(obj));(OUT/(stem+'.mtl')).write_text('\n'.join(mtl))
 blob=bytearray();views=[];access=[];meshes=[];nodes=[];materials=[]
 for name,o in groups.items():
  a=np.array(o['triangles'],dtype='<f4').reshape(-1,3);raw=a.tobytes();views.append({'buffer':0,'byteOffset':len(blob),'byteLength':len(raw),'target':34962});blob+=raw
  access.append({'bufferView':len(views)-1,'componentType':5126,'count':len(a),'type':'VEC3','min':a.min(0).tolist(),'max':a.max(0).tolist()})
  mat={'name':name,'pbrMetallicRoughness':{'baseColorFactor':o['color'],'metallicFactor':0,'roughnessFactor':.85},'doubleSided':True}
  if o['color'][3]<1:mat['alphaMode']='BLEND'
  materials.append(mat);meshes.append({'name':name,'primitives':[{'attributes':{'POSITION':len(access)-1},'material':len(materials)-1}]});nodes.append({'name':name,'mesh':len(meshes)-1})
 doc={'asset':{'version':'2.0','generator':'FLCC coordinated schematic reconstruction'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':materials,'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':access}
 raw=json.dumps(doc,separators=(',',':')).encode();raw+=b' '*(-len(raw)%4);blob+=b'\0'*(-len(blob)%4)
 (OUT/(stem+'.glb')).write_bytes(struct.pack('<III',0x46546c67,2,28+len(raw)+len(blob))+struct.pack('<II',len(raw),0x4e4f534a)+raw+struct.pack('<II',len(blob),0x004e4942)+blob)
 assert (OUT/(stem+'.stl')).stat().st_size==84+50*len(faces)
for i in CONFIG:export(json.loads((OUT/f'floor-{i}-data.json').read_text()),f'FLCC-aligned-floor-{i}')
export(allgroups,'FLCC-aligned-all-floors')
print('Exports complete; stair controls:',audits)
